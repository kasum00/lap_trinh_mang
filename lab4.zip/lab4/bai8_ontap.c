#include <pthread.h>
#include <stdio.h>

int global_var = 100;

void *thread_func(void *arg) {
    int local_var = 0;
    int thread_num = *(int *)arg;

    local_var += thread_num;
    global_var += thread_num;

    printf("Thread %d:\n", thread_num);
    printf("  Dia chi global_var: %p, gia tri = %d\n", (void *)&global_var, global_var);
    printf("  Dia chi local_var : %p, gia tri = %d\n", (void *)&local_var, local_var);

    return NULL;
}

int main() {
    pthread_t tid1, tid2;
    int a = 1, b = 2;

    printf("Main thread:\n");
    printf("  Dia chi global_var: %p, gia tri ban dau = %d\n\n", (void *)&global_var, global_var);

    pthread_create(&tid1, NULL, thread_func, &a);
    pthread_create(&tid2, NULL, thread_func, &b);

    pthread_join(tid1, NULL);
    pthread_join(tid2, NULL);

    printf("\nSau khi 2 luong chay xong:\n");
    printf("  global_var = %d\n", global_var);

    return 0;
}