// chua thu gom

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork failed");
        return 1;
    }

    if (pid == 0) {
        // Tiến trình con
        printf("Tien trinh con: PID = %d, PPID = %d\n", getpid(), getppid());
        printf("Tien trinh con ket thuc.\n");
        exit(0);
    } else {
        // Tiến trình cha
        printf("Tien trinh cha: PID = %d, con = %d\n", getpid(), pid);
        printf("Tien trinh cha ngu 30 giay, khong wait con.\n");
        sleep(30);
        printf("Tien trinh cha ket thuc.\n");
    }

    return 0;
}

// da thu gom
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork failed");
        return 1;
    }

    if (pid == 0) {
        // Tiến trình con
        printf("Tien trinh con: PID = %d, PPID = %d\n", getpid(), getppid());
        printf("Tien trinh con ket thuc.\n");
        exit(0);
    } else {
        // Tiến trình cha
        printf("Tien trinh cha: PID = %d, con = %d\n", getpid(), pid);
        printf("Tien trinh cha ngu 30 giay.\n");
        sleep(30);

        // Thu gom tiến trình zombie
        wait(NULL);   // Chờ tiến trình con kết thúc
        printf("Tien trinh cha da thu gom tien trinh zombie.\n");

        printf("Tien trinh cha ket thuc.\n");
    }

    return 0;
}