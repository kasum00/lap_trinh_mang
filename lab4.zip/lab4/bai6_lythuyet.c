#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <sys/wait.h>

#define PORT 8080
#define BUFFER_SIZE 1024

void handle_client(int client_sock){
    char buffer[BUFFER_SIZE];
    int bytes_received;
    
    while((bytes_received = recv(client_sock,buffer, sizeof(buffer)-1,0))>0){
        buffer[bytes_received]='\0';
        printf("nhan tu client: %s\n", buffer);

        send(client_sock,buffer,bytes_received,0);
    }

    printf("client da ngat ket noi.\n");
    close(client_sock);
}

int main(){
    int server_sock, client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);

    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if(server_sock<0){
        perror("socket");
        exit(1);
    }

    int opt=1;
    setsockopt(server_sock,SOL_SOCKET,SO_REUSEADDR,&opt,sizeof(opt));

    memset(&server_addr,0,sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port=htons(PORT);
    
    if(bind(server_sock, (struct sockaddr *)&server_addr,sizeof(server_addr))<0){
        perror("bind");
        close(server_sock);
        exit(1);
    }

    if(listen(server_sock,5)<0){
        perror("listen");
        close(server_sock);
        exit(1);
    }

    signal(SIGCHLD, SIG_IGN);

    printf("Server dang lang nghe tai cong %d...\n", PORT);

    while(1){
        client_sock = accept(server_sock, (struct sockaddr *)&client_addr, &client_len);
        if (client_sock < 0) {
            perror("accept");
            continue;
        }

        printf("Co ket noi moi tu %s:%d\n",
               inet_ntoa(client_addr.sin_addr),
               ntohs(client_addr.sin_port));

        pid_t pid = fork();

        if (pid < 0) {
            perror("fork");
            close(client_sock);
            continue;
        }

        if (pid == 0) {
            close(server_sock);
            handle_client(client_sock);
            exit(0);
        } else {
            close(client_sock);
        }
    }

    close(server_sock);
    return 0;

}