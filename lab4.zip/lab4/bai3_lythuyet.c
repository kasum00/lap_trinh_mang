#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main(){
    if(fork()!=0){
        printf("tiến trình cha\n");
    }
    else{
        printf("tiến trình con\n");
    }
}