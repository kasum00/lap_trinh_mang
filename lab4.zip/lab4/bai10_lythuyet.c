#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t pid1 = fork();

    if (pid1 < 0) {
        perror("fork pid1");
        exit(1);
    }

    if (pid1 == 0) {
        printf("Tien trinh con 1, PID = %d, PPID = %d\n", getpid(), getppid());
        exit(0);
    } else {
        pid_t pid2 = fork();

        if (pid2 < 0) {
            perror("fork pid2");
            exit(1);
        }

        if (pid2 == 0) {
            printf("Tien trinh con 2, PID = %d, PPID = %d\n", getpid(), getppid());
            exit(0);
        } else {
            printf("Tien trinh cha, PID = %d\n", getpid());
            wait(NULL);
            wait(NULL);
        }
    }

    return 0;
}