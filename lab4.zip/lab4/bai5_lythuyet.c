#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(){
    if(fork()==0){
        printf("tien trinh con\n");
        _exit(0);
    }
    else{
        wait(NULL); //thu don tien trinh con
        printf("tien trinh cha ket thuc\n");
    }
    return 0;
}