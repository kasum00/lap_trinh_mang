#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>

#define PORT 8080
#define BUF_SIZE 2048

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    char buffer[BUF_SIZE];
    char answer[16];

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("socket");
        return 1;
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("connect");
        close(sockfd);
        return 1;
    }

    while (1) {
        memset(buffer, 0, sizeof(buffer));
        int n = recv(sockfd, buffer, sizeof(buffer) - 1, 0);
        if (n <= 0) {
            printf("Mat ket noi toi server.\n");
            break;
        }

        printf("%s", buffer);

        if (strstr(buffer, "Nhap dap an") != NULL) {
            memset(answer, 0, sizeof(answer));
            fgets(answer, sizeof(answer), stdin);
            send(sockfd, answer, strlen(answer), 0);

            memset(buffer, 0, sizeof(buffer));
            n = recv(sockfd, buffer, sizeof(buffer) - 1, 0);
            if (n <= 0) {
                printf("Mat ket noi toi server.\n");
                break;
            }
            printf("%s", buffer);
        }

        if (strstr(buffer, "KET THUC") != NULL || strstr(buffer, "Tong diem") != NULL) {
            break;
        }
    }

    close(sockfd);
    return 0;
}