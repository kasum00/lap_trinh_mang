#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 8080
#define BACKLOG 10
#define BUF_SIZE 2048
#define NUM_QUESTIONS 10
#define NUM_OPTIONS 4

typedef struct {
    char question[256];
    char options[4][128];
    int correct; // chỉ số đáp án đúng gốc: 0..3
} QuizQuestion;

QuizQuestion quiz[NUM_QUESTIONS] = {
    {
        "1. Thu do cua Viet Nam la gi?",
        {"Ha Noi", "Hai Phong", "Da Nang", "TP. Ho Chi Minh"},
        0
    },
    {
        "2. 2 + 2 = ?",
        {"3", "4", "5", "6"},
        1
    },
    {
        "3. Ngon ngu lap trinh nao thuong dung de viet he dieu hanh Linux?",
        {"Python", "Java", "C", "PHP"},
        2
    },
    {
        "4. Hanh tinh nao duoc goi la Hanh tinh Do?",
        {"Trai Dat", "Sao Hoa", "Sao Moc", "Sao Kim"},
        1
    },
    {
        "5. Ham tao tien trinh con trong Linux la ham nao?",
        {"exec()", "fork()", "wait()", "pipe()"},
        1
    },
    {
        "6. Giao thuc nao huong ket noi?",
        {"UDP", "IP", "TCP", "ICMP"},
        2
    },
    {
        "7. 1 byte bang bao nhieu bit?",
        {"4", "8", "16", "32"},
        1
    },
    {
        "8. Lenh nao dung de bien dich chuong trinh C voi gcc?",
        {"gcc file.c -o file", "run file.c", "make gcc file", "compile file.c"},
        0
    },
    {
        "9. He dieu hanh nao ma nguon mo pho bien?",
        {"Windows", "Linux", "macOS", "iOS"},
        1
    },
    {
        "10. Cong mac dinh cua HTTP la bao nhieu?",
        {"21", "25", "80", "110"},
        2
    }
};

void reap_zombie(int sig) {
    (void)sig;
    while (waitpid(-1, NULL, WNOHANG) > 0) {
        // thu hồi tất cả tiến trình con đã kết thúc
    }
}

void shuffle_options(int order[4]) {
    for (int i = 0; i < 4; i++) order[i] = i;

    for (int i = 3; i > 0; i--) {
        int j = rand() % (i + 1);
        int tmp = order[i];
        order[i] = order[j];
        order[j] = tmp;
    }
}

void handle_client(int client_sock) {
    int score = 0;
    char buffer[BUF_SIZE];

    for (int i = 0; i < NUM_QUESTIONS; i++) {
        int order[4];
        shuffle_options(order);

        int correct_pos = -1;
        for (int j = 0; j < 4; j++) {
            if (order[j] == quiz[i].correct) {
                correct_pos = j;
                break;
            }
        }

        memset(buffer, 0, sizeof(buffer));
        snprintf(buffer, sizeof(buffer),
                 "%s\n"
                 "A. %s\n"
                 "B. %s\n"
                 "C. %s\n"
                 "D. %s\n"
                 "Nhap dap an (A/B/C/D): ",
                 quiz[i].question,
                 quiz[i].options[order[0]],
                 quiz[i].options[order[1]],
                 quiz[i].options[order[2]],
                 quiz[i].options[order[3]]);

        send(client_sock, buffer, strlen(buffer), 0);

        memset(buffer, 0, sizeof(buffer));
        int n = recv(client_sock, buffer, sizeof(buffer) - 1, 0);
        if (n <= 0) {
            printf("Client ngat ket noi som.\n");
            close(client_sock);
            exit(0);
        }

        char ans = buffer[0];
        if (ans >= 'a' && ans <= 'z') ans = ans - 'a' + 'A';

        int selected = -1;
        if (ans == 'A') selected = 0;
        else if (ans == 'B') selected = 1;
        else if (ans == 'C') selected = 2;
        else if (ans == 'D') selected = 3;

        memset(buffer, 0, sizeof(buffer));
        if (selected == correct_pos) {
            score++;
            snprintf(buffer, sizeof(buffer), "Dung! Ban duoc %d diem.\n\n", score);
        } else {
            char correct_letter = 'A' + correct_pos;
            snprintf(buffer, sizeof(buffer),
                     "Sai! Dap an dung la %c. Ban dang duoc %d diem.\n\n",
                     correct_letter, score);
        }

        send(client_sock, buffer, strlen(buffer), 0);
    }

    memset(buffer, 0, sizeof(buffer));
    snprintf(buffer, sizeof(buffer),
             "===== KET THUC =====\nTong diem cua ban: %d/%d\n",
             score, NUM_QUESTIONS);
    send(client_sock, buffer, strlen(buffer), 0);

    close(client_sock);
    exit(0);
}

int main() {
    int listen_sock, client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);

    srand(time(NULL));

    signal(SIGCHLD, reap_zombie);

    listen_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_sock < 0) {
        perror("socket");
        exit(1);
    }

    int opt = 1;
    if (setsockopt(listen_sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("setsockopt");
        close(listen_sock);
        exit(1);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(listen_sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind");
        close(listen_sock);
        exit(1);
    }

    if (listen(listen_sock, BACKLOG) < 0) {
        perror("listen");
        close(listen_sock);
        exit(1);
    }

    printf("Server dang lang nghe o cong %d...\n", PORT);

    while (1) {
        client_sock = accept(listen_sock, (struct sockaddr*)&client_addr, &client_len);
        if (client_sock < 0) {
            perror("accept");
            continue;
        }

        printf("Co client ket noi: %s:%d\n",
               inet_ntoa(client_addr.sin_addr),
               ntohs(client_addr.sin_port));

        pid_t pid = fork();

        if (pid < 0) {
            perror("fork");
            close(client_sock);
            continue;
        }

        if (pid == 0) {
            // tiến trình con
            close(listen_sock);
            handle_client(client_sock);
        } else {
            // tiến trình cha
            close(client_sock);
        }
    }

    close(listen_sock);
    return 0;
}