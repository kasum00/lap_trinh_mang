#include <stdio.h>
#include <pthread.h>

void *print_numbers(void *arg) {
    int *num = (int *)arg;
    printf("Number: %d\n", *num);
    return NULL;
}

int main(){
    pthread_t  tid;
    int num = 42;
    pthread_create(&tid, NULL, print_numbers, &num);    
    pthread_join(tid, NULL);
    return 0;
}