#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    for (int i = 0; i < 5; i++) {
        if (fork() == 0) {
            printf("Tien trinh con %d, PID = %d\n", i + 1, getpid());
            _exit(0);
        }
    }

    for (int i = 0; i < 5; i++) {
        wait(NULL);
    }

    printf("Tien trinh cha da thu don xong 5 tien trinh con.\n");
    return 0;
}