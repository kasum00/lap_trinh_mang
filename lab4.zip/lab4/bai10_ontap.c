#include <pthread.h>
#include <stdio.h>

void *thread_func(void *arg) {
    printf("Luong ket thuc\n");
    pthread_exit(NULL);
}

int main() {
    pthread_t tid;

    pthread_create(&tid, NULL, thread_func, NULL);
    pthread_join(tid, NULL);

    printf("Luong chinh ket thuc\n");

    return 0;
}