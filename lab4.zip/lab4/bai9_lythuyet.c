// #include <stdio.h>
// #include <stdlib.h>
// #include <unistd.h>
// #include <sys/types.h>
// #include <sys/socket.h>
// #include <arpa/inet.h>
// #include <string.h>

// int main() {
//     int listener;
//     int client_sock;
//     struct sockaddr_in server_addr;

//     // Tạo socket lắng nghe
//     listener = socket(AF_INET, SOCK_STREAM, 0);
//     if (listener < 0) {
//         perror("socket");
//         exit(1);
//     }

//     // Cấu hình địa chỉ server
//     memset(&server_addr, 0, sizeof(server_addr));
//     server_addr.sin_family = AF_INET;
//     server_addr.sin_addr.s_addr = INADDR_ANY;
//     server_addr.sin_port = htons(8080);

//     // Gắn địa chỉ vào socket
//     if (bind(listener, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
//         perror("bind");
//         close(listener);
//         exit(1);
//     }

//     // Chuyển sang trạng thái lắng nghe
//     if (listen(listener, 5) < 0) {
//         perror("listen");
//         close(listener);
//         exit(1);
//     }

//     // Tạo 3 tiến trình con
//     for (int i = 0; i < 3; i++) {
//         pid_t pid = fork();

//         if (pid < 0) {
//             perror("fork");
//             exit(1);
//         }

//         if (pid == 0) {
//             // Tiến trình con cùng chờ accept()
//             while (1) {
//                 client_sock = accept(listener, NULL, NULL);
//                 if (client_sock >= 0) {
//                     printf("Tien trinh con %d xu ly client\n", getpid());

//                     // Xử lý client ở đây
//                     char *msg = "Hello from child process\n";
//                     write(client_sock, msg, strlen(msg));

//                     close(client_sock);
//                 }
//             }
//             exit(0);
//         }
//     }

//     // Tiến trình cha không xử lý client
//     while (1) {
//         pause();
//     }

//     close(listener);
//     return 0;
// }

//mo hinh fork() sau accept()
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

int main() {
    int listener, client_sock;
    struct sockaddr_in server_addr;

    listener = socket(AF_INET, SOCK_STREAM, 0);
    if (listener < 0) {
        perror("socket");
        exit(1);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(8080);

    if (bind(listener, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind");
        close(listener);
        exit(1);
    }

    if (listen(listener, 5) < 0) {
        perror("listen");
        close(listener);
        exit(1);
    }

    printf("Server dang lang nghe cong 8080...\n");

    while (1) {
        client_sock = accept(listener, NULL, NULL);
        if (client_sock < 0) continue;

        pid_t pid = fork();

        if (pid == 0) {
            // Tiến trình con xử lý client
            close(listener);
            printf("Tien trinh con %d dang xu ly client\n", getpid());

            char *msg = "Hello client\n";
            write(client_sock, msg, strlen(msg));

            close(client_sock);
            exit(0);
        } else if (pid > 0) {
            // Tiến trình cha tiếp tục accept client mới
            close(client_sock);
        }
    }

    return 0;
}