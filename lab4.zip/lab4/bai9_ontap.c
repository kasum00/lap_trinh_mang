#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#define NUM_THREADS 5

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
FILE *fp;

void *write_file(void *arg) {
    int thread_id = *(int *)arg;

    pthread_mutex_lock(&lock);
    fprintf(fp, "Thread %d dang ghi vao file.\n", thread_id);
    pthread_mutex_unlock(&lock);

    return NULL;
}

int main() {
    pthread_t tids[NUM_THREADS];
    int ids[NUM_THREADS];

    fp = fopen("output.txt", "w");
    if (fp == NULL) {
        perror("fopen");
        return 1;
    }

    for (int i = 0; i < NUM_THREADS; i++) {
        ids[i] = i + 1;
        pthread_create(&tids[i], NULL, write_file, &ids[i]);
    }

    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(tids[i], NULL);
    }

    fclose(fp);
    pthread_mutex_destroy(&lock);

    printf("Da ghi xong du lieu vao file output.txt\n");

    return 0;
}