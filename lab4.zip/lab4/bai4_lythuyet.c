#include <stdio.h>
#include <unistd.h>

int main(){
    if(fork()==0){
        printf("tiến trình con kết thúc\n");
        _exit(0);
    }
    else{
        sleep(10); //tiến trình cha tạm dừng con trở thành zombie
    }
    return 0;
}