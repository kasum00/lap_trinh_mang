#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>

int main(){
    int listener, client_sock;
    pid_t pid;

    // Giả sử listener đã được tạo bằng socket(), bind(), listen()
    // Giả sử client_sock là socket trả về từ accept()

    pid = fork();

    if(pid<0){
        perror("fork");
        exit(1);
    }

    if(pid==0){
        //tien trinh con
        close(listener); //dong socket lang nghe
        printf("tien trinh con dang xu ly client\n");

        //xu ly client
        close(client_sock);// dong socket client sau khi xu ly xong
        exit(0);
    }
    else{
        //tien trinh cha
        close(client_sock); //cha khong can socket client nay
    }

    return 0;
}